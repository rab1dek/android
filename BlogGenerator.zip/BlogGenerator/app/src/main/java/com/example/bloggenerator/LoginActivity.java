package com.example.bloggenerator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    Button logbutton;
    Button regbut;
    FirebaseAuth mAuth;
    EditText ema;
    EditText passw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        logbutton = findViewById(R.id.loginbutton);
        regbut = findViewById(R.id.button2);
        ema = findViewById(R.id.login);
        passw = findViewById(R.id.passwd);
        mAuth = FirebaseAuth.getInstance();
        logbutton.setOnClickListener(view ->{
            loginUser();
        });
        regbut.setOnClickListener(view ->{
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    private void loginUser()
    {
        String email = ema.getText().toString();
        String password = passw.getText().toString();

        if(TextUtils.isEmpty(email)){
            ema.setError("Email nie może być pusty");
            ema.requestFocus();
        }else if (TextUtils.isEmpty(password))
        {
            passw.setError("Wpisz hasło");
            passw.requestFocus();
        }else
        {
            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(LoginActivity.this,"Zalogowałeś się", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    }else
                    {
                        Toast.makeText(LoginActivity.this,"Nie udało Ci się zalogować. Błąd: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}