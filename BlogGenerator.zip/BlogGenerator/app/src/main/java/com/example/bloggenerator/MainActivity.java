package com.example.bloggenerator;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    private Button button;
    private Spinner spin;
    private TextView txt;
    Button logout;
    String text = "";
    String tytul = "";
    FirebaseAuth mAuth;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logout = findViewById(R.id.logout);
        String[] strony = { "Sport", "Polityka", "Zdrowie", "Nauka", "Informatyka" };
        spin = (Spinner) findViewById(R.id.wybor);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, strony);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);
        mAuth = FirebaseAuth.getInstance();
        button = findViewById(R.id.btn1);
        txt = findViewById(R.id.edt2);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Sites");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openactivity2();
            }
        });
        logout.setOnClickListener(view ->{
            mAuth.signOut();
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            Toast.makeText(MainActivity.this,"Wylogowano", Toast.LENGTH_SHORT).show();
        });
    }
    public void openactivity2(){
        Intent intent = new Intent(this, BlogActivity.class);
        text = spin.getSelectedItem().toString();
        tytul = txt.getText().toString();
        mAuth = FirebaseAuth.getInstance();
        String username = mAuth.getCurrentUser().getEmail();
        Sites sites = new Sites(username, tytul, text);
        databaseReference.push().setValue(sites);
        Toast.makeText(MainActivity.this, "Stworzyles strone!", Toast.LENGTH_SHORT).show();
        intent.putExtra("name", text);
        intent.putExtra("tytul", tytul);
        startActivity(intent);
    }
    protected void onStart() {
        super.onStart();
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null)
        {
            startActivity(new Intent(MainActivity.this, RegisterActivity.class));
        }
    }
}