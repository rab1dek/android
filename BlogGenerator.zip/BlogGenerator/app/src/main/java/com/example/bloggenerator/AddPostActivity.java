package com.example.bloggenerator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddPostActivity extends AppCompatActivity {
    EditText title;
    EditText desc;
    Button add;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_post);

        title = findViewById(R.id.title);
        desc = findViewById(R.id.description);
        add = findViewById(R.id.add);
        mAuth = FirebaseAuth.getInstance();

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Posts");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adddata();
            }
        });
    }
    private void adddata()
    {
        String titl = title.getText().toString();
        String dsc = desc.getText().toString();
        Intent intent = getIntent();
        String siema = intent.getStringExtra("name");
        String username = mAuth.getCurrentUser().getEmail();
        Posts posts = new Posts(titl,dsc, username, siema);
        databaseReference.push().setValue(posts);
        Toast.makeText(AddPostActivity.this, "Dodano post!", Toast.LENGTH_SHORT).show();

    }
}