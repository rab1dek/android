package com.example.bloggenerator;


public class Sites {
    String username;
    String title;
    String spiner;

    public Sites(String username, String title, String spiner) {
        this.username = username;
        this.title = title;
        this.spiner = spiner;
    }

    public String getUsername() {
        return username;
    }

    public String getTitle() {
        return title;
    }

    public String getSpiner() {
        return spiner;
    }
}

