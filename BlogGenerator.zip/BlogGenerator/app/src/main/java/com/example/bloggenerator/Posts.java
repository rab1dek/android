package com.example.bloggenerator;

public class Posts {
    String title;
    String desc;
    String username;
    String category;

    public Posts(String title, String desc, String username, String category) {
        this.title = title;
        this.desc = desc;
        this.username = username;
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public String getUsername() {
        return username;
    }

    public String getCategory() {
        return category;
    }
}
