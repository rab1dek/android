package com.example.bloggenerator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class BlogActivity extends AppCompatActivity {
    Button addpost;
    ListView listView;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blog);
        TextView txt1 = findViewById(R.id.edt3);
        TextView txt2 = findViewById(R.id.kategoria);
        listView = findViewById(R.id.lista);
        Intent intent = getIntent();
        String siema = intent.getStringExtra("name");
        String tytul = intent.getStringExtra("tytul");
        mAuth = FirebaseAuth.getInstance();

        if (siema.equals("Sport"))
        {
            View view = this.getWindow().getDecorView();
            ((View) view).setBackgroundColor(0xfff00000);
            txt1.setText(tytul);
            txt2.setText(siema);
        }
        if (siema.equals("Polityka"))
        {
            View view = this.getWindow().getDecorView();
            ((View) view).setBackgroundColor(Color.parseColor("#1aa2d4"));
            txt1.setText(tytul);
            txt2.setText(siema);
        }
        if (siema.equals("Zdrowie"))
        {
            View view = this.getWindow().getDecorView();
            ((View) view).setBackgroundColor(Color.parseColor("#BFFF00"));
            txt1.setText(tytul);
            txt2.setText(siema);
        }
        if (siema.equals("Nauka"))
        {
            View view = this.getWindow().getDecorView();
            ((View) view).setBackgroundColor(Color.parseColor("#808080"));
            txt1.setText(tytul);
            txt2.setText(siema);
        }
        if (siema.equals("Informatyka"))
        {
            View view = this.getWindow().getDecorView();
            ((View) view).setBackgroundColor(Color.parseColor("#9090ff"));
            txt1.setText(tytul);
            txt2.setText(siema);
        }
        addpost = findViewById(R.id.addpost);
        addpost.setOnClickListener(view -> {
            Intent intent2 = new Intent(this, AddPostActivity.class);
            intent2.putExtra("name", siema);
            startActivity(intent2);

        });
        final ArrayList<String> list = new ArrayList<>();
        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.list_item, list);
        listView.setAdapter(adapter);
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Posts");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot snap : snapshot.getChildren())
                {
                    String username = mAuth.getCurrentUser().getEmail();
                    if(snap.getValue().toString().contains(username) && snap.getValue().toString().contains(siema)) {
                        String txt = snap.getValue().toString();
                        String txtNew = txt.replace("{", "");
                        String txtNew2 = txtNew.replace("}", "");
                        String txtNew3 = txtNew2.replace("=","");
                        String txtNew4 = txtNew3.replace("category","Kategoria:");
                        String txtNew5 = txtNew4.replace("title","Tytuł:");
                        String txtNew6 = txtNew5.replace("desc","Opis:");
                        String txtNew7 = txtNew6.replace("username","Autor:");
                        list.add(txtNew7);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}