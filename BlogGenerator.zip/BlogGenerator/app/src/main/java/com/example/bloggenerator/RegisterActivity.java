package com.example.bloggenerator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    EditText em;
    EditText pass;
    Button btnRegister;
    Button lgn;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        em = findViewById(R.id.emailreg);
        pass = findViewById(R.id.paswd);
        btnRegister = findViewById(R.id.button);
        mAuth = FirebaseAuth.getInstance();
        btnRegister.setOnClickListener(view -> {
            createUser();
        });
        lgn = findViewById(R.id.button3);
        lgn.setOnClickListener(view -> {
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        });
    }
    private void createUser(){
        String email = em.getText().toString();
        String password = pass.getText().toString();

        if(TextUtils.isEmpty(email)){
            em.setError("Email nie może być pusty");
            em.requestFocus();
        }else if (TextUtils.isEmpty(password))
        {
            pass.setError("Wpisz hasło");
            pass.requestFocus();
        }else{
            mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(RegisterActivity.this,"Stworzyłeś konto", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                    }else
                    {
                        Toast.makeText(RegisterActivity.this,"Nie udało Ci się stworzyć konta. Błąd: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }

}